package com.student_management_system2._db.example.student_management_system2_db;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentManagementSystem2DbApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentManagementSystem2DbApplication.class, args);
	}

}
