package com.student_management_system2._db.example.student_management_system2_db;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentManagementSystem2DbApplicationTests {

	@Test
	void contextLoads() {
	}

}
