package com.student_management_system2.example.student_management_system2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentManagementSystem2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
