package com.jpahibernateexample.student_management_system_db;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentManagementSystemDbApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentManagementSystemDbApplication.class, args);
	}

}
