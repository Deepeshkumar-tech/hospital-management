package com.jpahibernateexample.student_management_system_db;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentManagementSystemDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
